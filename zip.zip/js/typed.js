// type js
var options = {
  strings: [
    "am a Web Developer.",
    `<i class="text-danger fa-solid fa-heart"></i> to code.`,
    `code.. <i class="fa-solid fa-terminal text-success"></i>Hello World!<i class="fa-solid fa-code text-info"></i>`,
  ],
  typeSpeed: 100,
  backSpeed: 100,
  loop: true,
};

var typed = new Typed(".auto-type", options);
